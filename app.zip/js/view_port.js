function hideEverybody(){
	$('#properties').hide();
	$('#welcome_message').hide();
	$('#workspace').hide();
	$('#view_port').hide();
	$('#seacor').hide();
	$('#draw_canvas').hide();
	$('#floorplan').hide();
//	$('#sub_workspace').hide();
//	$('#div_floorplan').hide();
//	$('#div_floorplan_door').hide();
//	$('#div_floorplan_window').hide();
//	$('#div_floorplan_floor').hide();
//	$('#div_floorplan_cabinet').hide();
//	$('#div_floorplan_appliances').hide();
//	$('#add_door').hide();
}
